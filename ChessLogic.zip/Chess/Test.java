import java.util.Scanner;

class Test {
    
    //public static void main(String[] args) {
      //  Game g = new Game();
        /**
        Board b = g.getCurrentPos();
        for(int i = 0; i < 8; i++) {
            for(int j = 0; j < 8; j++) {
                b.getTiles()[i][j].setPiece(null);
            }
        }
        b.getTiles()[0][0].setPiece(new Rook(0));
        b.getTiles()[4][0].setPiece(new Rook(0));
        b.getTiles()[0][1].setPiece(new Pawn(0));
        b.getTiles()[1][1].setPiece(new Pawn(0));
        b.getTiles()[4][1].setPiece(new Knight(0));
        b.getTiles()[5][1].setPiece(new King(0));
        b.getTiles()[6][1].setPiece(new Pawn(0));
        b.getTiles()[7][1].setPiece(new Pawn(0));
        b.getTiles()[1][2].setPiece(new Queen(0));
        b.getTiles()[2][2].setPiece(new Pawn(0));
        b.getTiles()[2][2].getPiece().setMoved(1);
        b.getTiles()[5][2].setPiece(new Pawn(0));
        b.getTiles()[5][2].getPiece().setMoved(1);
        b.getTiles()[6][2].setPiece(new Bishop(0));
        b.getTiles()[3][3].setPiece(new Pawn(0));
        b.getTiles()[3][3].getPiece().setMoved(1);
        b.getTiles()[4][3].setPiece(new Pawn(0));
        b.getTiles()[4][3].getPiece().setMoved(1);
        b.getTiles()[2][4].setPiece(new Pawn(1));
        b.getTiles()[2][4].getPiece().setMoved(1);
        b.getTiles()[4][4].setPiece(new Pawn(1));
        b.getTiles()[4][4].getPiece().setMoved(1);
        b.getTiles()[6][4].setPiece(new Pawn(1));
        b.getTiles()[6][4].getPiece().setMoved(1);
        b.getTiles()[7][4].setPiece(new Knight(1));
        b.getTiles()[1][5].setPiece(new Pawn(1));
        b.getTiles()[1][5].getPiece().setMoved(1);
        b.getTiles()[3][5].setPiece(new Pawn(1));
        b.getTiles()[3][5].getPiece().setMoved(1);
        b.getTiles()[5][5].setPiece(new Queen(1));
        b.getTiles()[7][5].setPiece(new Pawn(1));
        b.getTiles()[7][5].getPiece().setMoved(1);
        b.getTiles()[0][6].setPiece(new Pawn(1));
        b.getTiles()[2][6].setPiece(new Knight(0));
        b.getTiles()[3][6].setPiece(new Knight(1));
        b.getTiles()[4][6].setPiece(new King(1));
        b.getTiles()[5][6].setPiece(new Pawn(1));
        b.getTiles()[6][6].setPiece(new Bishop(1));
        b.getTiles()[0][7].setPiece(new Rook(1));
        b.getTiles()[4][7].setPiece(new Pawn(1));
        b.getKingTiles()[0] = b.getTiles()[5][1];
        b.getKingTiles()[1] = b.getTiles()[4][6];
        b.getKings()[0] = (King) b.getKingTiles()[0].getPiece();
        b.getKings()[1] = (King) b.getKingTiles()[1].getPiece();
        System.out.println(b);
        b.nextTurn();
        System.out.println(b.legal("e7", "f8"));
        g.move("e7", "f8");
        System.out.println(b);
        
        g.move("e2", "e4");
        g.move("d7", "d6");
        g.move("f1", "b5");
        g.move("c8", "d7");
        g.move("b5", "d7");
        g.move("b8", "d7");
        g.move("d2", "d4");
        g.move("e7", "e5");
        g.move("g1", "e2");
        g.move("g8", "f6");
        g.move("f2", "f3");
        g.move("d8", "e7");
        g.move("c1", "g5");
        g.move("h7", "h6");
        g.move("g5", "h4");
        g.move("g7", "g5");
        g.move("h4", "g3");
        g.move("f8", "g7");
        g.move("e1", "f2");
        g.move("f6", "h5");
        g.move("h1", "e1");
        g.move("e7", "f6");
        g.move("c2", "c3");
        g.move("e8", "e7");
        g.move("d1", "b3");
        g.move("b7", "b6");
        g.move("b1", "a3");
        g.move("h8", "e8");
        g.move("a3", "b5");
        g.move("c7", "c5");
        g.move("b5", "c7");
        g.move("e7", "f8");
        System.out.println(g.getCurrentPos());
        
        g.move("a2", "a4");
        g.move("h7", "h5");
        g.move("a4", "a5");
        g.move("h5", "h4");
        g.move("a5", "a6");
        g.move("g7", "g5");
        g.move("a6", "b7");
        g.move("g5", "g4");
        g.move("b7", "a8");
        System.out.println(g.getCurrentPos());
        */
    //}
    
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        String t1;
        String t2;
        int[] forPromotions;
        Game g = new Game();
        g.move("a2", "a4");
        g.move("h7", "h5");
        g.move("a4", "a5");
        g.move("h5", "h4");
        g.move("a5", "a6");
        g.move("g7", "g5");
        g.move("a6", "b7");
        g.move("g5", "g4");
        System.out.println("RADOMIRCHESS");
        System.out.println("Enter the square that the piece you want to move is on, followed by the square that you want the piece to move to, separated by a space");
        System.out.println("Example: e2 e4");
        while(!g.getCurrentPos().ended()) {
            System.out.println(g.getCurrentPos());
            if(g.getCurrentPos().getToMove() == Constants.WHITE) {
                System.out.println("White to move");
            }
            else if(g.getCurrentPos().getToMove() == Constants.BLACK) {
                System.out.println("Black to move");
            }
            do {
                t1 = s.next();
                t2 = s.next();
                s.nextLine();
            } while(!g.getCurrentPos().legal(t1, t2));
            g.move(t1, t2);
            //code for promoting pawns (hopefully this works lol i haven't tested it yet)
            forPromotions = Constants.chessToCoord(t2);
            System.out.println("For debugging: ");
            System.out.println("t2: " + t2);
            System.out.println("forPromotions[1]: " + forPromotions[1]);
            System.out.println("7*g.getCurrentPos().getToMove(): " + 7*g.getCurrentPos().getToMove());
            System.out.println("g.getCurrentPos().getTiles()[forPromotions[0]][forPromotions[1]].getPiece().getName(): " + g.getCurrentPos().getTiles()[forPromotions[0]][forPromotions[1]].getPiece().getName());
            if(forPromotions[1] == 7*g.getCurrentPos().getToMove() && g.getCurrentPos().getTiles()[forPromotions[0]][forPromotions[1]].getPiece().getName().equals("p")) {
                System.out.println("Promote pawn on " + t2 + " to what?");
                System.out.println("Q: Queen\nR: Rook\nB: Bishop\nN: Knight");
                do {
                    t1 = s.next();
                    s.nextLine();
                } while(!(t1.equals("Q") || t1.equals("R") || t1.equals("B") || t1.equals("N")));
                if(t1.equals("Q")) {
                    g.getCurrentPos().getTiles()[forPromotions[0]][forPromotions[1]].setPiece(new Queen(1 - g.getCurrentPos().getToMove()));
                }
                else if(t1.equals("R")) {
                    g.getCurrentPos().getTiles()[forPromotions[0]][forPromotions[1]].setPiece(new Rook(1 - g.getCurrentPos().getToMove()));
                }
                else if(t1.equals("B")) {
                    g.getCurrentPos().getTiles()[forPromotions[0]][forPromotions[1]].setPiece(new Bishop(1 - g.getCurrentPos().getToMove()));
                }
                else if(t1.equals("N")) {
                    g.getCurrentPos().getTiles()[forPromotions[0]][forPromotions[1]].setPiece(new Knight(1 - g.getCurrentPos().getToMove()));
                }
            }
        }
        s.close();
    }
}